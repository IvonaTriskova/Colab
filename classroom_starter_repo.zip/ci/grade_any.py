
import sys, os, re, json, nbformat, glob, pathlib
from nbclient import NotebookClient

ROOT = pathlib.Path(".").resolve()

# Prefer CZ; if not found, try EN; else search any .ipynb in notebooks/
CANDIDATES = [
    ROOT / "notebooks" / "Reflexe_IM_cloud_SS_CZ.ipynb",
    ROOT / "notebooks" / "Reflection_CT_cloud_HS_EN.ipynb",
]

nb_path = None
for p in CANDIDATES:
    if p.exists():
        nb_path = p
        break
if nb_path is None:
    nbs = list((ROOT / "notebooks").glob("*.ipynb"))
    if nbs:
        nb_path = nbs[0]

if nb_path is None:
    print("No notebook found in notebooks/", file=sys.stderr)
    sys.exit(0)  # return zero to avoid failing setup; tests will just not pass

print(f"[grader] Executing: {nb_path}")

# Load notebook
nb = nbformat.read(nb_path, as_version=4)

# Execute top-to-bottom with allow_errors=True to continue past asserts
client = NotebookClient(nb, timeout=600, kernel_name="python3", allow_errors=True)
client.execute()

# Extract grading lines from outputs
t1 = t1_max = t2 = t2_max = t3 = t3_max = tc = tc_max = total = tmax = None
pattern = re.compile(r"T1 \(sum_even\):\s*([\d\.]+)/(\d+)|T2 \(compute_stats\):\s*([\d\.]+)/(\d+)|T3 \(char_freq\):\s*([\d\.]+)/(\d+)|C \(normalize_grades\):\s*([\d\.]+)/(\d+)|TOTAL|CELKEM", re.I)

for cell in nb.cells:
    if cell.cell_type != "code":
        continue
    for out in cell.get("outputs", []):
        text = ""
        if out.get("output_type") == "stream":
            text = out.get("text", "")
        elif out.get("output_type") in ("execute_result", "display_data"):
            data = out.get("data", {})
            text = data.get("text/plain", "")
        if not text:
            continue
        # per-task values
        m = re.findall(r"T1 \(sum_even\):\s*([\d\.]+)/(\d+)", text)
        if m:
            t1, t1_max = float(m[-1][0]), float(m[-1][1])
        m = re.findall(r"T2 \(compute_stats\):\s*([\d\.]+)/(\d+)", text)
        if m:
            t2, t2_max = float(m[-1][0]), float(m[-1][1])
        m = re.findall(r"T3 \(char_freq\):\s*([\d\.]+)/(\d+)", text)
        if m:
            t3, t3_max = float(m[-1][0]), float(m[-1][1])
        m = re.findall(r"C \(normalize_grades\):\s*([\d\.]+)/(\d+)", text)
        if m:
            tc, tc_max = float(m[-1][0]), float(m[-1][1])
        m = re.findall(r"(TOTAL|CELKEM):\s*([\d\.]+)/(\d+)", text, re.I)
        if m:
            total = float(m[-1][1]); tmax = float(m[-1][2])

# Threshold-based pass tokens (>=90% of weight)
def passed(score, maxv):
    try:
        return (score is not None) and (maxv is not None) and maxv > 0 and (score / maxv) >= 0.9
    except ZeroDivisionError:
        return False

if passed(t1, t1_max): print("PASS_T1")
if passed(t2, t2_max): print("PASS_T2")
if passed(t3, t3_max): print("PASS_T3")
if passed(tc, tc_max): print("PASS_C")

if total is not None and tmax is not None:
    print(f"TOTAL_POINTS={total}/{tmax}")
else:
    print("TOTAL_POINTS=0/0")
