
# Classroom Starter – Computational Thinking (Cloud Notebook)

This repository contains two ready-to-use Jupyter/Colab notebooks (CZ & EN) for a reflection lesson with **hidden tests** and **configurable weights**. It is prepared for **GitHub Classroom** autograding.

## Contents
- `notebooks/Reflexe_IM_cloud_SS_CZ.ipynb` – Czech version
- `notebooks/Reflection_CT_cloud_HS_EN.ipynb` – English version
- `ci/grade_any.py` – headless execution & scoring parser (used by autograding)
- `.github/workflows/classroom.yml` – runs GitHub Classroom autograder
- `autograding.json` – 4 weighted tests (T1,T2,T3,C)
- `requirements.txt` – notebook execution deps
- `.gitattributes` – text normalization

> **Tip:** Keep only one language for a given assignment to avoid confusion. The autograder will grade across whichever notebook is present (it prefers CZ if both exist).

## For teachers (GitHub Classroom)
1. Create a **new assignment** and choose **Import from a repository** → select this starter.
2. In assignment settings, enable **Autograding**.
3. Students will:
   1. Solve tasks in the notebook.
   2. Run the **Grading** cell (prints per-task points).
   3. Export CSV (+ PDF) as instructed.
   4. Commit `.ipynb` + `.csv` (+ `.pdf` if required).

### Scoring
- Tests award points if task score reaches a **90% threshold** of the task weight.
  - T1=4, T2=8, T3=8, C=5 → **total 25**.
- Partial points are recorded in the notebook and CSV, but Classroom awards points per test (pass/fail).

### Change weights
Weights are set inside the notebook (locked for students). If you need to change them for this assignment, edit the WEIGHTS cell **before** publishing. The autograding thresholds adapt automatically.

## For students
- Work **top-to-bottom** in the notebook.
- Run the **Grading** cell.
- Use the **Save/Export** cell to create CSV (contains your points).
- Commit your `.ipynb` and `.csv` to your assignment repo.
